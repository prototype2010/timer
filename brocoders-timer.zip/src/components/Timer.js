import React, {Component} from 'react';
import {connect} from 'react-redux';
import styled from 'styled-components'
import {
    Input,
    Button,
    withStyles,
    Dialog,
    DialogActions,
    DialogContent,
    DialogContentText,
    DialogTitle
} from '@material-ui/core';
import Clock from './Clock'
import {REDUX_ACTION_NAMES, STYLES} from '../config'

const {CONTROL_TASKS_FLOW, SET_TASK_NAME} = REDUX_ACTION_NAMES;
const {TEXT_COLOR, LIGHT_BLUE, WARN_COLOR} = STYLES;

const TimerContainer = styled.div`
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-content: space-between;
    align-items: center;
    color: ${TEXT_COLOR};
    padding: 30px;
`;

const CloseDialogButton = withStyles({
    root: {
        color: LIGHT_BLUE,
        fontWeight: 'bold'
    },
})(Button);

const TimerButton = withStyles({
    root: {
        borderRadius: 3,
        border: 0,
        color: TEXT_COLOR,
        height: 48,
        padding: '0 30px',
        boxShadow: '0 3px 5px 2px lightgray',
        fontSize: '20px'
    },
    label: {
        textTransform: 'capitalize',
    },
})(Button);

const TaskNameInput = withStyles({
    root: {
        width: '450px',
        fontSize: '20px',
        color: `${TEXT_COLOR}`
    }
})(Input);

class Timer extends Component {

    state = {
        showAlert: false
    };

    openAlert = () => {
        this.setState({showAlert: true})
    };

    closeAlert = () => {
        this.setState({showAlert: false})
    };

    handleTimerButtonClick = () => {

        const {startTime, taskName, controlTasksFlow} = this.props;

        if (startTime && !taskName) {
            this.openAlert();
        } else {
            controlTasksFlow();
        }
    };

    render() {

        const {startTime, taskName} = this.props;

        return (
            <TimerContainer>

                <TaskNameInput
                    onChange={this.props.handleTaskNameChange}
                    placeholder={'Name of your task'}
                    value={taskName}
                    inputProps={{
                        style: {
                            textAlign: "center",
                        }
                    }}
                />

                <Dialog open={this.state.showAlert}>
                    <DialogTitle>
                        <p style={{color: `${WARN_COLOR}`, fontWeight: 'bold', fontSize: '24px'}}>
                            Empty task name
                        </p>
                    </DialogTitle>
                    <DialogContent>
                        <DialogContentText>
                            You are trying close task without name, enter the title and try again
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <CloseDialogButton onClick={this.closeAlert}>
                            Close
                        </CloseDialogButton>
                    </DialogActions>
                </Dialog>

                <Clock startTime={startTime}/>

                <TimerButton
                    size={'large'}
                    onClick={this.handleTimerButtonClick}
                >
                    {startTime ? 'STOP' : 'START'}
                </TimerButton>

            </TimerContainer>
        )
    }
}

export default connect(
    state => ({...state.tasks}),
    dispatch => ({
        controlTasksFlow: () => dispatch({
            type: CONTROL_TASKS_FLOW
        }),
        handleTaskNameChange: event => dispatch({
            type: SET_TASK_NAME,
            payload: event.target.value
        })
    })
)(Timer);