import React from 'react';
import {withStyles} from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';

import {formatDate, getFormattedDifference} from '../utils/timeFormatter';

const CustomTableCell = withStyles(theme => ({
    head: {
        backgroundColor: theme.palette.common.white,
        color: theme.palette.common.gray,
    },
    body: {
        fontSize: 14,
    },
}))(TableCell);

const styles = theme => ({
    root: {
        width: '100%',
        marginTop: theme.spacing.unit * 3,
        overflowX: 'auto',
    },
    table: {
        minWidth: 700,
    },
    row: {
        '&:nth-of-type(odd)': {
            backgroundColor: theme.palette.background.default,
        },
    },
});

const TasksCustomizedTable = withStyles(styles)(CustomizedTable);

function CustomizedTable(props) {
    const {classes, tasks} = props;

    return (
        <Paper className={classes.root}>
            <Table className={classes.table}>
                <TableHead>
                    <TableRow>
                        <CustomTableCell>№</CustomTableCell>
                        <CustomTableCell align="right">Task</CustomTableCell>
                        <CustomTableCell align="right">Time start</CustomTableCell>
                        <CustomTableCell align="right">Time end</CustomTableCell>
                        <CustomTableCell align="right">Time spend</CustomTableCell>
                        <CustomTableCell align="right">Info</CustomTableCell>
                        <CustomTableCell align="right">Delete</CustomTableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {tasks.map((row, i) => {

                        const {taskName, startTime, endTime, id} = row;

                        return (
                            <TableRow className={classes.row} key={row.id}>
                                <CustomTableCell component="th" scope="row">{i + 1}</CustomTableCell>
                                <CustomTableCell align="right">{taskName}</CustomTableCell>
                                <CustomTableCell align="right">{formatDate(startTime)}</CustomTableCell>
                                <CustomTableCell align="right">{formatDate(endTime)}</CustomTableCell>
                                <CustomTableCell
                                    align="right">{getFormattedDifference(startTime, endTime)}</CustomTableCell>
                                <CustomTableCell align="right">
                                    <button>AAAAAAA</button>
                                </CustomTableCell>
                                <CustomTableCell align="right">
                                    <button onClick={() => props.deleteTask(id)}>DELETE</button>
                                </CustomTableCell>
                            </TableRow>)

                    })}
                </TableBody>
            </Table>
        </Paper>
    );
}


export default TasksCustomizedTable;