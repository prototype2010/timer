import React from 'react';
import {connect} from 'react-redux';
import {Route, Switch, Link} from "react-router-dom";
import Timer from './components/Timer';
import TasksTable from './components/TasksTable';

import {REDUX_ACTION_NAMES, ROUTER_PREFIXES} from './config';

const {CHECK_SERIALIZED_STATE, DELETE_TASK} = REDUX_ACTION_NAMES;

class App extends React.Component {

    componentDidMount() {
        this.props.recoverState();
    }

    render() {

        const {tasksList, deleteTask} = this.props;

        return (
            <div>

                {JSON.stringify(this.props)}
                <hr/>
                <br/>

                <Timer/>

                <Switch>

                    <Route
                        path={'/'}
                        exact
                        render={props => <TasksTable {...props} deleteTask={deleteTask} tasks={tasksList}/>}
                    />

                    {/*<Route path={'/'} component={}/>*/}
                    {/*<Route path={`${BROWSER_PATH_PREFIX}${REALTIME_PAGE_SUFFIX}`} component={RealTime}/>*/}
                </Switch>
            </div>

        )
    }
}

export default connect(
    state => ({...state.tasks}),
    dispatch => ({
        recoverState: () => dispatch({
            type: CHECK_SERIALIZED_STATE
        }),
        deleteTask: taskId => dispatch({
            type: DELETE_TASK,
            payload: taskId
        })
    })
)(App)