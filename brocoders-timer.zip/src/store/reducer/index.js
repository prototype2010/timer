import {combineReducers} from 'redux';

import applicationState from './applicationState';
import tasks from './tasks';

export default combineReducers({
    applicationState,
    tasks
});