import {compose, createStore, applyMiddleware} from 'redux';
import recoverSerializedState from './saga/recoverSerializedState';
import serializeState from './saga/serializeState';
import controlTaskFlow from './saga/controlTaskFlow';

import rootReducer from './reducer'
import reduxLogger from './middleware/logger';
import createSagaMiddleware from 'redux-saga';

/* redux devtools */
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const sagaMiddleware = createSagaMiddleware();

export default createStore(rootReducer, composeEnhancers(applyMiddleware(reduxLogger, sagaMiddleware)));

[recoverSerializedState, serializeState, controlTaskFlow]
    .forEach(saga => sagaMiddleware.run(saga));